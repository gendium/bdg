
export const FirebaseConfig = {
  apiKey: "<Web API Key>",
  authDomain: ".firebaseapp.com",
  databaseURL: "https://bodega-b9345.firebaseio.com/"
};
