import { combineReducers } from "redux";

import data from "./dataReducer";

export default combineReducers({
  data
});
