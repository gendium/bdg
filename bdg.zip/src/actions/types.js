export const FETCH_TODOS = 'FETCH_TODOS';
export const FETCH_USER = 'FETCH_USER';
